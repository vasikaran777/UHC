
const map = L.map('map').setView([13.0827, 80.2707], 13);
L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
    attribution: '© OpenStreetMap contributors'
}).addTo(map);

// Dummy heat zone polygon
const heatPolygon = L.polygon([
    [13.08, 80.25],
    [13.08, 80.26],
    [13.09, 80.26],
    [13.09, 80.25]
], {
    color: 'red',
    fillColor: '#e31a1c',
    fillOpacity: 0.6
}).addTo(map);
heatPolygon.bindPopup("Heat Zone");

// Weather API (OpenWeatherMap)
const lat = 13.0827;
const lon = 80.2707;
const apiKey = "YOUR_OPENWEATHERMAP_API_KEY";  // Replace this

fetch(`https://api.openweathermap.org/data/2.5/weather?lat=${lat}&lon=${lon}&appid=${apiKey}&units=metric`)
    .then(response => response.json())
    .then(data => {
        const temp = data.main.temp;
        document.getElementById('temp').textContent = temp + "°C";

        // Show alert if temp >= 40
        if (temp >= 40) {
            document.getElementById('alert-banner').style.display = 'block';
        }

        // Set heat risk
        document.getElementById('heat-risk').textContent = calculateHeatRisk(temp);
    })
    .catch(err => {
        console.error("Weather API error:", err);
        document.getElementById('temp').textContent = "Error";
    });

function calculateHeatRisk(temp) {
    if (temp >= 40) return 'Very High';
    else if (temp >= 35) return 'High';
    else if (temp >= 30) return 'Moderate';
    else return 'Low';
}
